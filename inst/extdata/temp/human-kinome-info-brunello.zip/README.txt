4/5/2016
This document was created by the Genetic Perturbation Platform regarding the submission of the arrayed Kinome Library to Addgene.  Since platemaps will be provided in our preferred format they will be missing certain required fields on the batch upload form provided by Addgene.  This document will attempt to map columns from our platemaps to those fields in the batch upload form, as well as provide values for columns for required fields that were not provided by our document.

*****

GPP Platemap Column Name -> Addgene Batch Upload Column Name

Platemap -> Plate Name
Well -> Well
Clone ID -> Plasmid Name
Target Sequence -> gRNA/shRNA sequence
Taxon -> Species of gene of insert
Vector -> Backbone Name
Orig. Target Gene ID -> Gene or Insert Name
Orig. Target Gene Symbol -> Alternative Gene/Insert Name 1

*****

Additional Req'd Column Information

Column Name -> Value

Purpose -> CRISPR/Cas9
Relevant Mutations -> Blank
Primary Vector Type -> Lentiviral
Cloning Method -> Restriction Enzyme
Bacterial Resistance -> Ampicillin
high or low copy -> High Copy
Growth Temp -> 37 C
Growth Strain -> DH5Alpha
